function splash() {
    window.top.location.href = "./Main/sindex.html";
}

document.querySelector(".rainbow-text").addEventListener("click", () => {
        splash();
};